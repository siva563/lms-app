const UploadCheatsheet = () => {
    return (
        <div>
            <h5>Upload Cheatsheet</h5>
            {/* We'll build the full form next */}
        </div>
    );
};

export default UploadCheatsheet;
