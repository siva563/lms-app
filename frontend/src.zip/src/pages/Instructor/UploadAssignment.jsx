const UploadAssignment = () => {
    return (
        <div>
            <h5>Upload Assignment</h5>
            {/* Form coming soon */}
        </div>
    );
};

export default UploadAssignment;