const UploadMCQ = () => {
    return (
        <div>
            <h5>Upload MCQs</h5>
            {/* Form content will go here */}
        </div>
    );
};

export default UploadMCQ;
